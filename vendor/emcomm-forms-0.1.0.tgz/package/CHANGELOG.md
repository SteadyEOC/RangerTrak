# Changelog

All notable changes. Versions follow semantic versioning; before 1.0, a minor version may break the API.

## 0.1.0 (2026-11-18)

First release.

- `writeSaveData(formId, values)`: Winlink form "Save Data" files for Load Data in Winlink Express and
  Pat. ICS-213, ICS-213RR, ICS-214, ICS-205, HICS-251, Hospital Status, Field Situation (Standard Forms
  1.1.22.0). Byte for byte against 13 real saves. Also `saveDataFields`, `saveDataTemplateVersion`,
  `SAVE_DATA_FORMS`.
- `writePlainText(message, options)`: title, labelled fields and text, 72 columns, CRLF, folded to
  US-ASCII, ISO-8859-1 or kept as UTF-8.
- `writeB2f(message)`: Pat outbox messages, byte for byte against six Pat 1.0.1 messages.
- `writeFlmsg(file)`, `wrapFlmsg(name, text)`, `crc16Modbus`: FLMSG `.213`, `.309`, `.p2s`, `.c2s` and the
  `[WRAP]` envelope. **Untested against a real FLMSG save.**
- `check(bytes, name, options)` and the `emcomm-forms` CLI: strict checker for Save Data, viewer XML,
  `FormData.txt`, Pat `.b2f` and Winlink Express exports; profiles, rule overrides, SARIF.
- Helpers: `asciiFold`, `wrapText`, `encodeUtf8/Latin1/Ascii`, quoted-printable, RFC 5322 and B2F dates,
  XML escaping, Maidenhead grid, message ids.
